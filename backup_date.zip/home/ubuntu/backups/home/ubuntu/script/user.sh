#!/bin/bash

#./user.sh rahul rahul@123

echo "username $1"
echo "password $2"

sudo useradd -m -p 
