!#/bin/bash

<<info
this shell scrip to take regular backup

info

src=$1
dest=$2

timestamp=$(date '+%y-%m-%d-%H-%M')
zip -r "$dest/backup-$timestamp.zip" $src

echo "backup done"
