#!/bin/bash

<<info

loops anything which we repeat again and again based on condition

info


for (( num=1 ; num<=10 ; num++ ))

do
	echo "$num"
	echo "hello"


done

