#!/bin/bash

<<info

pavakge

info






read -p "user name is :" user
read -p "passwdord is :" password


function usercreate {
sudo useradd -m -p "$user" "$password"
echo -e "$password\n$password" | sudo passwd "$user"

}

function delete {

sudo userdel $user

}

function user_check {

cat /etc/passwd | grep -i "$user" | wc | awk '{print $1}'

count=$(cat /etc/passwd | grep -i "$user" | wc | awk '{print $1}')
if [ $count == 0 ];
then
	echo " userNA "
else
	echo " userA "

fi

}

usercreate
delete
user_check
usercreate
delete
user_check
