!#
<<info

backuo pratice

info

$1=sour
$2=dest

zip -r $2/backup_date '+%y-%m-%d-%H-%M-%S' $1



